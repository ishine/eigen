#ifndef CONFIG_H_
#define CONFIG_H_

#define VERSION "0.1.85"
#define PACKAGE "sentencepiece"
#define PACKAGE_STRING "sentencepiece"


#endif  // CONFIG_H_
